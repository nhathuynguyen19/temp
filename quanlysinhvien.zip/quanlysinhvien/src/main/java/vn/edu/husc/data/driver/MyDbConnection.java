package vn.edu.husc.data.driver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import vn.edu.husc.data.utils.Constants;

public class MyDbConnection {

    private static MyDbConnection _instance = null;
    private Connection _connection;
    private MyDbConnection() {
        try {
            _connection = DriverManager.getConnection(Constants.URL, Constants.USER, Constants.PASSWORD);
            System.out.println("Connection established successfully!");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database");
            e.printStackTrace();
        }
    }

    public static MyDbConnection getInstance() {
        if (_instance == null) {
            _instance = new MyDbConnection();
        }
        return _instance;
    }

    public Connection getConnection() {
        return _connection;
    }
}
