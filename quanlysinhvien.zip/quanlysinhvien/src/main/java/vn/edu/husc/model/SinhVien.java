package vn.edu.husc.model;

public class SinhVien {
    private String msv;
    private String hoTen;
    private Float dtb;

    public SinhVien(String msv, String hoTen, Float dtb) {
        this.msv = msv;
        this.hoTen = hoTen;
        this.dtb = dtb;
    }

    public String getMsv() {
        return msv;
    }

    public void setMsv(String msv) {
        this.msv = msv;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Float getDtb() {
        return dtb;
    }

    public void setDtb(Float dtb) {
        this.dtb = dtb;
    }

    @Override
    public String toString() {
        return msv + "|" + hoTen + "|" + dtb;
    }
}
