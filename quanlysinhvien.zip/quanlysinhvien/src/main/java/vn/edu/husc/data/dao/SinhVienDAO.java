package vn.edu.husc.data.dao;

import java.util.List;

import vn.edu.husc.model.SinhVien;

public interface SinhVienDAO {
    public List<SinhVien> findAll();
    public Boolean findByMSV(String msv);
    public void insert(SinhVien sv);
    public void deleteByMSV(String msv);
    public void update(SinhVien sv);
}
