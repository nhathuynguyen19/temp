package vn.edu.husc;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import vn.edu.husc.data.dao.Database;
import vn.edu.husc.data.dao.SinhVienDAO;
import vn.edu.husc.model.SinhVien;

public class Main {
    public static void main(String[] args) {
    	ArrayList<SinhVien> ds = SinhVienRepo.readListSinhVien();
        SinhVienDAO svdao = Database.getSinhVienDAO();
        for (SinhVien sv : ds) {
        	svdao.insert(sv);
        }
        List<SinhVien> list = svdao.findAll();
        list.forEach(System.out::println);
    }
}