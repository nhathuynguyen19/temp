package vn.edu.husc.data.dao;

import vn.edu.husc.data.impl.SinhVienImpl;

public class Database {
    public static SinhVienImpl getSinhVienDAO() {
        return new SinhVienImpl();
    }
}
