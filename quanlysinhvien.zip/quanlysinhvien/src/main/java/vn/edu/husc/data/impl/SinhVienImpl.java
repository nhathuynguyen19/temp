package vn.edu.husc.data.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vn.edu.husc.data.dao.SinhVienDAO;
import vn.edu.husc.data.driver.MyDbConnection;
import vn.edu.husc.model.SinhVien;

public class SinhVienImpl implements SinhVienDAO {

    @Override
    public List<SinhVien> findAll() {
        List<SinhVien> list = new ArrayList<>();
        String query = "SELECT * FROM SinhVien ORDER BY dtb DESC";

        try {
            Connection conn = MyDbConnection.getInstance().getConnection();
            PreparedStatement sttm = conn.prepareStatement(query);
            ResultSet rs = sttm.executeQuery();

            while (rs.next()) {
                list.add(new SinhVien(
                        rs.getString("msv"),
                        rs.getString("hoten"),
                        rs.getFloat("dtb")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Boolean findByMSV(String msv) {
        String query = "SELECT 1 FROM SinhVien WHERE msv = ?";

        try {
            Connection conn = MyDbConnection.getInstance().getConnection();
            PreparedStatement sttm = conn.prepareStatement(query);
            sttm.setString(1, msv);
            ResultSet rs = sttm.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void insert(SinhVien sv) {
        if (findByMSV(sv.getMsv())) {
            System.out.println("MSV đã tồn tại, không thể thêm!");
            return;
        }

        String query = "INSERT INTO SinhVien(msv, hoten, dtb) VALUES (?, ?, ?)";

        try {
            Connection conn = MyDbConnection.getInstance().getConnection();
            PreparedStatement sttm = conn.prepareStatement(query);

            sttm.setString(1, sv.getMsv());
            sttm.setString(2, sv.getHoTen());
            sttm.setFloat(3, sv.getDtb());

            sttm.executeUpdate();
            System.out.println("Thêm sinh viên thành công!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void deleteByMSV(String msv) {
        String query = "DELETE FROM SinhVien WHERE msv = ?";

        try {
            Connection conn = MyDbConnection.getInstance().getConnection();
            PreparedStatement sttm = conn.prepareStatement(query);
            sttm.setString(1, msv);
            sttm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(SinhVien sv) {
        String query = "UPDATE SinhVien SET hoten = ?, dtb = ? WHERE msv = ?";

        try {
            Connection conn = MyDbConnection.getInstance().getConnection();
            PreparedStatement sttm = conn.prepareStatement(query);
            sttm.setString(1, sv.getHoTen());
            sttm.setFloat(2, sv.getDtb());
            sttm.setString(3, sv.getMsv());
            sttm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
