package vn.edu.husc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import vn.edu.husc.model.SinhVien;

public class SinhVienRepo {
    public static ArrayList<SinhVien> readListSinhVien() {
        ArrayList<SinhVien> rs = new ArrayList<>();
        try {
            FileReader f = new FileReader("sv.txt");
            BufferedReader br = new BufferedReader(f);
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split("\\|");
                if (data.length == 3) {
                    String msv = data[0];
                    String hoten = data[1];
                    Float dtb = Float.parseFloat(data[2]);
                    SinhVien sv = new SinhVien(msv, hoten, dtb);
                    rs.add(sv);
                }
            }
            br.close();
        } catch (IOException e) {
            System.err.println("Lỗi khi đọc file: " + e.getMessage());
        }
        return rs;
    }
}
