package vn.edu.husc.data.utils;

public class Constants {
    public static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=mtkquanlysinhvien;trustServerCertificate=true";
    public static final String USER = "sa";
    public static final String PASSWORD = "1234";
}
